# Inventory Manager - Guida Utente

## Introduzione

Inventory Manager è un software completo per la gestione del magazzino che ti permette di:

- Importare dati da file Excel di diversi formati
- Gestire carico e scarico di prodotti
- Utilizzare lettori di codici a barre per operazioni rapide
- Generare report dettagliati sull'inventario
- Monitorare lo stato del magazzino e gli articoli in esaurimento

## Requisiti di Sistema

- Python 3.6 o superiore
- Librerie: pandas, openpyxl, xlrd (installate automaticamente dallo script di setup)
- Sistema operativo: Windows, macOS o Linux

## Installazione

1. Estrai il file zip in una cartella a tua scelta
2. Apri un terminale o prompt dei comandi
3. Naviga alla cartella del programma
4. Esegui lo script di setup:

```
python setup.py
```

Questo script installerà tutte le dipendenze necessarie e creerà la struttura delle cartelle richiesta.

## Avvio del Programma

Dopo l'installazione, avvia il programma con:

```
python src/main.py
```

## Funzionalità Principali

### Dashboard

La schermata principale mostra:
- Numero totale di prodotti
- Quantità totale in magazzino
- Articoli con scorte basse
- Attività recenti

### Gestione Inventario

Nella scheda "Inventory" puoi:
- Visualizzare tutti i prodotti in magazzino
- Cercare prodotti specifici
- Selezionare un prodotto per operazioni di carico/scarico
- Aggiungere o rimuovere quantità dal magazzino

### Importazione Dati

Nella scheda "Import Data" puoi:
- Selezionare un file Excel da importare
- Specificare il fornitore
- Visualizzare un'anteprima del file
- Importare i dati nel database

Il sistema supporta diversi formati di file Excel e rileva automaticamente le intestazioni delle colonne.

### Lettore Codici a Barre

Nella scheda "Barcode Scanner" puoi:
- Scansionare codici EAN/UPC
- Visualizzare i dettagli del prodotto scansionato
- Aggiungere o rimuovere stock rapidamente
- Visualizzare la cronologia delle scansioni

### Reportistica

Nella scheda "Reports" puoi generare:
- Report sullo stato dell'inventario
- Elenco degli articoli con scorte basse
- Cronologia delle transazioni
- Registro degli eventi
- Esportare i report in formato Excel

## Flussi di Lavoro Comuni

### Importazione di un Nuovo Listino Prezzi

1. Vai alla scheda "Import Data"
2. Clicca su "Browse" e seleziona il file Excel
3. Verifica che il nome del fornitore sia corretto
4. Clicca su "Import Data"

### Aggiunta di Stock

1. Vai alla scheda "Inventory"
2. Seleziona un prodotto dalla lista
3. Inserisci la quantità da aggiungere
4. Aggiungi eventuali riferimenti o note
5. Clicca su "Add Stock"

### Utilizzo del Lettore di Codici a Barre

1. Vai alla scheda "Barcode Scanner"
2. Scansiona il codice a barre (o inseriscilo manualmente)
3. Verifica i dettagli del prodotto
4. Inserisci la quantità
5. Clicca su "Add Stock" o "Remove Stock"

### Generazione di Report

1. Vai alla scheda "Reports"
2. Seleziona il tipo di report
3. Imposta eventuali filtri (es. intervallo di date)
4. Clicca su "Generate Report"
5. Per salvare il report, clicca su "Export to Excel"

## Risoluzione dei Problemi

### Errori di Importazione

- Verifica che il file Excel sia nel formato corretto (.xlsx o .xls)
- Controlla che il file contenga le colonne necessarie (codice prodotto, descrizione, prezzi)
- Prova a specificare manualmente il numero di righe da saltare se l'intestazione non viene rilevata correttamente

### Problemi con i Codici a Barre

- Assicurati che i codici a barre siano nel formato EAN/UPC standard
- Verifica che il prodotto sia stato importato correttamente nel database
- Controlla che il campo EAN/UPC sia stato mappato correttamente durante l'importazione

### Altri Problemi

Se riscontri altri problemi, verifica:
- Che tutte le dipendenze siano installate correttamente
- Che il database non sia danneggiato
- I log di sistema per messaggi di errore specifici

## Supporto

Per assistenza tecnica o domande sul software, contatta il supporto all'indirizzo email fornito con il pacchetto software.



## 6. Gestione Eventi Annuali (Nuova Funzionalità)

La nuova scheda "Events" permette di importare e analizzare i dati degli eventi annuali, come quelli presenti nel file `PROGRAMMAPROVVISORIO2025.xlsx`.

### 6.1. Importazione Dati Eventi

1.  Vai alla scheda **Events**.
2.  Nella sezione **Import Annual Events Data**, clicca su **Browse** per selezionare il tuo file Excel.
3.  Una volta selezionato il file, clicca su **Import Events**.
4.  I dati verranno importati e visualizzati nella tabella **Annual Events List**.

### 6.2. Visualizzazione e Statistiche

- La tabella **Annual Events List** mostra tutti gli eventi importati con i relativi dettagli.
- Nella sezione **Annual Event Statistics**, puoi inserire un anno e cliccare su **Generate Statistics** per visualizzare un riepilogo annuale dettagliato che include incassi, costi, profitto e altre metriche chiave.

